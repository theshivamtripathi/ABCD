import Render from "./Render";
const App=()=>{
    return (
        <>
        <Render/>
        </>
    )
}
export default App;